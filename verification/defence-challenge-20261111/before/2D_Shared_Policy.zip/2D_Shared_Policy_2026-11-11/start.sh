#!/usr/bin/env bash
set -eu
cd -- "$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)"
exec python3 server.py --open "$@"
