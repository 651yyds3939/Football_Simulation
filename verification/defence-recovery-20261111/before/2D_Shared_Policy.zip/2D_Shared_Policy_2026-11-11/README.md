# 共用 Python 决策的一攻一防二维测试

## 启动

本版需要 Python 3.8 或更新版本，只用标准库，不需要安装 Webots、ROS、Conda 或 pip 包。Ubuntu 可直接使用自带的 Python 3。运行：

```bash
bash start.sh
```

或者：

```bash
python3 server.py --open
```

浏览器会打开终端打印的 `http://127.0.0.1:端口/`。不要直接双击 `viewer.html`，它需要连接 Python 服务。保持终端运行；终端按 `Ctrl+C` 停止服务。整个服务只在本机运行，不需要互联网。

实时决策在 Python 中计算，浏览器只提交控制命令和画图，不含另一套 JavaScript 决策或运动模型。

## Windows 启动

1. 安装 Python 3.8 或更新版本，参考 [Python 官方 Windows 安装说明](https://docs.python.org/3/using/windows.html)。不需要安装 Webots、Conda 或额外的 Python 包。
2. 将 ZIP **完整解压**到一个文件夹，不要在压缩包内直接运行。
3. 双击 `start_windows.bat`。脚本自动查找 `py -3` 或 `python`，启动本机服务并打开浏览器；未找到合适的 Python 时会提示安装。
4. 在网页点击 **Play** 开始。运行期间保持命令窗口打开；在该窗口按 `Ctrl+C` 停止。若 Windows 随后询问是否终止批处理，输入 `Y` 并回车。

也可以在解压目录打开 PowerShell 或命令提示符，运行：

```powershell
py -3 server.py --open
```

若只有 `python` 命令，则运行 `python server.py --open`。脚本支持带空格的目录。启动后浏览器没有自动打开时，将命令窗口打印的 `http://127.0.0.1:端口/` 复制到浏览器地址栏。

仅播放现成演示时，直接双击 `example_replay.html` 即可，不需要 Python。`viewer.html` 是实时界面，需要通过上述服务打开。

Windows 启动入口与文件编码已做兼容处理，尚未在真实 Windows 系统上实测。这里的兼容范围是二维测试包；完整 Webots 三维项目还需要单独配置 Webots 与控制器环境。

## 共用哪些代码

```text
                   相同的世界状态、朝向和策略配置
                                |
              PolicyProfile.py：创建同一套策略与导航器
                                |
                  TeamPolicy.py：行为、目标、踢球意图
                                |
                  Navigation.py：走路、转向、侧移、踢球请求
                           /            \
                二维执行适配器          Webots 执行适配器
                平面平均速度模型        关节动作、IMU 与安全调度
                        |                    |
                更新二维世界状态        更新三维世界状态
```

浏览器底部显示实际加载的代码来源、策略 SHA-256 前缀和配置。`guarded` 对应射门目标伸入球门 0.30 m；`legacy` 对应原来的 0 m。两边必须使用相同配置再做比较。

目录位于原项目旁时，默认直接导入相邻 `Webots_Robotics_TDP` 的真实 Python 文件，不使用另写的决策副本。移到其他电脑后自动使用包内 `backend/` 的同版本快照。`python3 server.py --bundled --open` 可强制验证打包快照。

当前复用的是策略、导航和配置。二维不复现 Webots 的 IMU 滤波、站稳等待、步态阶段门控、关节执行、接触动力学或摔倒恢复。输入轨迹在运行中发生差异后，后续决策也可能不同。共用代码不代表两种环境会有相同的进球率。

## 操作

- **Play / 开始**：实时运行，默认 2 倍速。可选 1、2、4、8、16、32、64 倍；加速仅增加每秒计算的步数，不修改机器人速度参数。
- **New random setup / 随机新开局**：更换位置、朝向和种子。
- **Repeat seed / 重测当前种子**：复现同一个开局。
- **Fast test ×20 / 快速测试 20 次**：暂停显示，直接让 Python 尽快计算连续 20 个种子，显示结果与实际耗时。随机场景会改变位置；固定场景只改变踢球噪声，结果类别可能相同。
- **Export HTML replay / 导出 HTML 回放**：用同一套 Python 决策算完当前场景，再保存单个 HTML。该文件可以直接双击、离线分享；这是回放，不能在没有 Python 的情况下修改策略或开局。
- **Download run data / 下载数据**：保存输入配置、代码来源哈希、轨迹、行为和事件。
- 暂停后可拖动球员或足球，到目标位置松开鼠标后提交。重叠位置会被拒绝。

解围只记录事件，继续攻防。进球、出界或本轮到时才结束。可开启自动下一轮。

## 双方挤在球旁怎么办

时间继续增加、足球几乎不动，属于攻防僵持；时间也完全停止时，先检查是否暂停、切到后台，或 Python 服务已退出。

当前版本修正了二维碰撞后剩余位移被丢弃的问题，并在共用 Python 策略中加入 **DUEL_ESCAPE / Create space / 遇堵让位**。当双方贴近、足球连续约 8 秒没有移动超过 0.06 m 时，争球球员会尝试短暂侧移，再重新争球。目标侧移 0.12 m，单次最多 8 秒；实际位移仍受动作速度、碰撞和执行器限制。这些阈值是策略假设，不是课程规定或真机标定值。

没有强制移动足球、提高机器人速度或规定哪方获胜。修改同时进入 Webots 使用的 `TeamPolicy.py` 和 `Navigation.py`；二维碰撞修正只影响二维执行器。

更新后必须在旧终端按 `Ctrl+C` 停止服务，再重新运行启动脚本，并打开新终端打印的网址。仅刷新网页不会重新加载已经导入的 Python 策略。

同条件 20 个种子（27–46，随机开局、每轮 180 秒、guarded/centre）的超时由 6 次降至 1 次。另 100 个种子（47–146）的超时由 28 次降至 13 次，仍存在失败场景。这是简化二维模型内的前后对照，不能作为三维或真机成功率。

可在页面选择 `random`、种子 `28`、时长 `180`，观察遇堵让位和后续攻防；种子 `37` 仍可能反复僵持，应保留为后续改进用例。下载 JSON 可保留种子、模型、代码哈希和全过程；不要只换开局而丢弃失败记录。

## 快速批量测试

```bash
python3 server.py --batch 20 --scenario random --seed 27 --seconds 180 \
  --locomotion guarded --output runs/baseline_01
```

输出目录必须是新目录，防止覆盖基线。得到 `metrics.json` 和第一场完整的 `replay.html`。计算尽快执行，不受浏览器播放倍速限制。输出同时记录仿真时间与实际计算时间。

改动后用同样的种子、时长、配置复测：

```bash
python3 server.py --batch 20 --scenario random --seed 27 --seconds 180 \
  --locomotion guarded --output runs/candidate_01
```

## 修改和三维验证

在原工作区主要修改：

```text
Webots_Robotics_TDP/Wenao/controllers/Utils/TeamPolicy.py
Webots_Robotics_TDP/Wenao/controllers/Utils/Navigation.py
```

修改后重启 Python 服务，并重新加载 Webots 控制器，避免还在运行旧版本。一次修改一个问题。先比较相同种子下的二维目标、动作切换、触球与结果，再做三维对照。不要只比较某一次是否进球。

普通 Webots 世界默认使用 `legacy`。如果二维选择 `guarded`，三维也应显式使用相同配置，例如在原项目根目录运行 `TDP_LOCOMOTION=guarded TDP_FINISHING_AIM=centre ./launch.sh`。这不会把普通四对四世界自动变成一攻一防；一攻一防接口检查使用下一节的独立测试入口。

原仓库新增的短三维接口检查：

```bash
cd ../Webots_Robotics_TDP
conda activate robotics-tdp
python tests/run_shared_policy_webots.py --seconds 12 --locomotion guarded \
  --output runs/shared_policy_3d_01
python tools/check_policy_trace.py runs/shared_policy_3d_01
```

该检查使用原来的两个物理控制器，其他六台停在场外并从策略观测中排除。它记录 Webots 实际输入，再由共用 Python 模块重算，检查行为、目标、请求动作和导航阶段是否一致。它不是完整攻防成功率验收，也不验证二维和三维轨迹一致。

## 分享和系统要求

实时版：分享整个 ZIP；接收方需要 Python 3.8+，在浏览器打开服务网址。无第三方 Python 依赖。已在当前 Ubuntu 上验证；Windows 双击 `start_windows.bat`，macOS 使用 `python3 server.py --open`，尚未在这两个系统实测。

纯展示：分享导出的单个 `replay.html`，不需要 Python。包内 `example_replay.html` 是由共用策略算出的固定门前场景，明确标为离线回放。


## English quick start

Run `python3 server.py --open` and keep the terminal open. Only Python 3.8+ and a browser are required; there are no third-party dependencies. The browser displays states computed by the same Python `TeamPolicy` and `Navigator` modules used by Webots. It does not contain a parallel JavaScript policy.

On Windows, install Python, extract the entire ZIP, then double-click `start_windows.bat`. Keep its console open and stop with Ctrl+C. Alternatively run `py -3 server.py --open`. Windows has not been tested on a native system. The included `example_replay.html` opens directly without Python for offline playback.

Use **Fast test ×20** for compute-bound policy screening, or the `--batch` command above. **Export HTML replay** produces an offline, shareable single-file recording computed by Python. Live scene editing and new policy calculations require the server.

The adjacent original workspace is preferred automatically. A portable source snapshot is used when that workspace is absent, or when `--bundled` is selected. Restart after code edits; match the `guarded`/`legacy` and finishing settings across environments. Policy/navigation are shared; physics, motion scheduling, sensing and stability are not.
