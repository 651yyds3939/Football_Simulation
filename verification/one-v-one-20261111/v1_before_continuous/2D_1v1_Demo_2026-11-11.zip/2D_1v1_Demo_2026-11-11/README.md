# 2D football: one attacker, one defender, one ball

## 打开和展示

解压整个压缩包，双击 `index.html`，用 Chrome、Edge、Firefox 或 Safari 等现代浏览器打开。无须联网、Webots、ROS、Python、Conda 或本地服务器。Windows、macOS 和 Linux 均可通过浏览器打开。

Ubuntu 终端也可以运行：

```bash
xdg-open index.html
```

1. 点击 **Play / 开始**。红方进攻右侧球门，蓝方尝试拦截并向左解围。
2. **Playback / 播放速度** 默认 8×，用于缩短观看时间。切回 1× 可观察原始仿真速度，倍速不会更改运动参数。
3. 选择 **Midfield duel / 中场攻防**、**Open-lane attack / 边路进攻** 或 **Near-goal finish / 门前射门**。三个场景始终只有两名球员和一个球。
4. 暂停后可以拖动球员或足球，改变初始位置。点击 **Reset / 重置** 恢复当前场景和种子。
5. 点击右上角 **中文 / English** 切换语言。
6. 右侧显示当前状态、足球位置、最近触球和射门/解围触球次数。可以下载本次运行的 JSON 记录。

每次测试在进球、出界、实际解围完成或达到 180 秒仿真时间时结束，不自动伪造进球或重播成功镜头。解围成功的简化判据为蓝方完成解围触球，之后足球向左移动至少 0.18 m。不同场景和初始位置可以产生不同结果。

## 与现有项目的关系

沿用课程球场和球门尺寸，以及原项目中已记录的 Webots 平均运动速度、动作时间与部分球运动参数。这个小演示采用单独编写的一攻一防控制逻辑；它不是原四对四控制器的原样移植，也不是 Webots 三维仿真录像。

二维模型使用精确位置，只检查平面运动与球员交互，不模拟相机、关节、平衡或摔倒。当前简化接触、踢球范围和运动参数不代表真实 NAO6 已标定的性能。来源与建模选择见 `MODEL_NOTES.md`、`model_parameters.json`。

## Open and present

Extract the ZIP and open **index.html** in a modern browser. No installation, network connection, Python, ROS, Webots or local server is required.

- Press **Play**. Red attacks the right goal; blue intercepts and clears left.
- Choose one of the three starting scenes. Use **Reset** to repeat the same setup and seed.
- Default playback is **8×**. Change to **1×** for simulated real-time motion. The multiplier changes viewing time only.
- Pause to drag a player or the ball. Manual edits are identified in exported run data.
- Switch between English and Chinese with the top-right button.
- Download run data as JSON for positions, states, contacts and outcomes.

Each attempt ends on a goal, an exit, a completed clearance, or a 180-second simulation timeout. A clearance requires an actual defender kick contact followed by at least 0.18 m leftward ball travel.

This is an independent 1v1 planar demonstration using selected parameters from the existing project. It does not port the existing 4v4 policy or demonstrate real NAO6 perception, dynamics or balance. See **MODEL_NOTES.md** for sources and limits.

## Files

| File | Purpose |
|---|---|
| `index.html` | Complete simulator, controller logic, drawing and bilingual interface; works by itself |
| `model_parameters.json` | Embedded model values, assumptions and original source hashes |
| `MODEL_NOTES.md` | Parameter sources, state policies and model limits |
| `README.md` | Opening and presentation instructions |

Sharing the ZIP preserves the documentation. Sharing just `index.html` is sufficient to run the demonstration.
